<?php

namespace App\Http\Interfaces;


interface testRepositoryInterface
{

    public function getAll();
}